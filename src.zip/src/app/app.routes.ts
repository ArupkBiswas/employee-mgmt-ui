import { RouterModule, RouterOutlet, Routes } from '@angular/router';
import { LoginComponent } from './auth/login/login.component';
import { App } from './app';

export const appRoutes: Routes = [
  //{ path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  { path: 'employees', component: App },
  //{ path: '**', redirectTo: 'login' }
];


export const routes = RouterOutlet
